#!/usr/bin/env bash
# shortforge 설치 — Crostini(Debian) / Arch(baguette) / Ubuntu 공용
#   bash install.sh
# 패키지 하나가 없어도 죽지 않는다. 뭐가 빠졌는지 끝에 정리해서 알려준다.
set -uo pipefail   # -e 는 일부러 뺐다: apt 실패 하나로 전체가 죽으면 안 된다
cd "$(dirname "$0")"
HERE="$(pwd)"
MISSING=()

say()  { printf '\033[1;32m▸ %s\033[0m\n' "$*"; }
warn() { printf '\033[1;33m! %s\033[0m\n' "$*"; }
die()  { printf '\033[1;31m✗ %s\033[0m\n' "$*"; exit 1; }

# ---------- 0. 환경 ----------
. /etc/os-release 2>/dev/null || true
say "환경: ${PRETTY_NAME:-unknown}  ($(uname -m))"
grep -qi crostini /etc/apt/sources.list.d/* 2>/dev/null && say "ChromeOS Linux(Crostini) 감지"

# ---------- 1. 시스템 패키지 ----------
apt_one() { sudo apt-get install -y -qq "$1" >/dev/null 2>&1 && echo "  ok   $1" || { echo "  MISS $1"; MISSING+=("$1"); }; }
pac_one() { sudo pacman -S --needed --noconfirm "$1" >/dev/null 2>&1 && echo "  ok   $1" || { echo "  MISS $1"; MISSING+=("$1"); }; }

if command -v apt-get >/dev/null; then
  say "apt 패키지 설치 (sudo 비밀번호 한 번)"
  sudo apt-get update -qq || warn "apt update 실패 — 계속 진행"
  for p in ffmpeg python3 python3-venv python3-pip fonts-dejavu-core curl unzip; do apt_one "$p"; done
  # 크로미움: Debian 은 chromium, Ubuntu 계열은 chromium-browser
  apt_one chromium
  command -v chromium >/dev/null || command -v chromium-browser >/dev/null || apt_one chromium-browser
elif command -v pacman >/dev/null; then
  say "pacman 패키지 설치"
  sudo pacman -Sy --noconfirm >/dev/null 2>&1 || true
  for p in ffmpeg chromium python python-pip ttf-dejavu curl unzip; do pac_one "$p"; done
else
  die "apt 도 pacman 도 없다. ffmpeg, chromium, python3 를 직접 설치하고 다시 실행해라."
fi

# ---------- 2. 필수 확인 ----------
command -v ffmpeg >/dev/null || die "ffmpeg 가 없다. 이게 없으면 영상 렌더가 불가능하다."
BROWSER=$(command -v chromium || command -v chromium-browser || command -v google-chrome || true)
[ -n "$BROWSER" ] && say "브라우저: $BROWSER" || warn "크로미움이 없다 — 업로드(로그인)가 안 된다. 나중에 'sudo apt install chromium' 다시 시도해라."

PY=$(command -v python3)
PYV=$("$PY" -c 'import sys;print("%d.%d"%sys.version_info[:2])')
say "python $PYV ($PY)"
"$PY" -c 'import sys;sys.exit(0 if sys.version_info>=(3,10) else 1)' || die "python 3.10 이상이 필요하다 (현재 $PYV)"

# ---------- 3. 파이썬 환경 ----------
say "가상환경(.venv) + 의존성"
[ -d .venv ] || "$PY" -m venv .venv || die "venv 생성 실패 — 'sudo apt install python3-venv' 후 다시"
.venv/bin/pip install -q --upgrade pip setuptools wheel || warn "pip 업그레이드 실패 — 계속"
if ! .venv/bin/pip install -q -e . ; then
  warn "의존성 설치 실패. 개별로 재시도한다(어떤 게 문제인지 보려고)."
  for pkg in requests numpy soundfile pillow cryptography onnxruntime kokoro-onnx playwright; do
    .venv/bin/pip install -q "$pkg" && echo "  ok   $pkg" || { echo "  MISS $pkg"; MISSING+=("py:$pkg"); }
  done
  .venv/bin/pip install -q -e . --no-deps || die "shortforge 패키지 설치 실패"
fi
.venv/bin/python -c 'import shortforge.local.app' || die "shortforge import 실패"

# ---------- 4. 런처 ----------
say "런처: ~/.local/bin/shortforge"
mkdir -p "$HOME/.local/bin"
printf '#!/usr/bin/env bash\ncd "%s" && exec .venv/bin/python -m shortforge "$@"\n' "$HERE" > "$HOME/.local/bin/shortforge"
chmod +x "$HOME/.local/bin/shortforge"
case ":$PATH:" in *":$HOME/.local/bin:"*) ;; *)
  echo 'export PATH="$HOME/.local/bin:$PATH"' >> "$HOME/.bashrc"
  warn '~/.local/bin 을 PATH 에 추가했다. 새 터미널부터 `shortforge` 명령이 먹는다.' ;;
esac

# ---------- 5. 백그라운드 서비스 ----------
if command -v systemctl >/dev/null && systemctl --user show-environment >/dev/null 2>&1; then
  say "백그라운드 서비스 등록"
  mkdir -p "$HOME/.config/systemd/user"
  cat > "$HOME/.config/systemd/user/shortforge-web.service" <<EOF
[Unit]
Description=shortforge local app (http://127.0.0.1:8787)
After=network-online.target

[Service]
WorkingDirectory=$HERE
ExecStart=$HERE/.venv/bin/python -m shortforge web --no-open
Restart=always
RestartSec=5
Environment=DISPLAY=:0
Environment=WAYLAND_DISPLAY=wayland-0
Environment=XDG_RUNTIME_DIR=/run/user/$(id -u)

[Install]
WantedBy=default.target
EOF
  systemctl --user daemon-reload
  systemctl --user enable --now shortforge-web.service 2>/dev/null \
    && say "서비스 가동 중 (systemctl --user status shortforge-web)" \
    || warn "서비스 등록 실패 — 터미널에서 'shortforge web' 으로 직접 띄워라."
  loginctl enable-linger "$USER" >/dev/null 2>&1 || true
else
  warn "systemd 사용자 세션이 없다 — 터미널에서 'shortforge web' 으로 직접 띄워라."
fi

# ---------- 6. 런처 아이콘 ----------
mkdir -p "$HOME/.local/share/applications"
cat > "$HOME/.local/share/applications/shortforge.desktop" <<EOF
[Desktop Entry]
Type=Application
Name=shortforge
Comment=Faceless Shorts factory
Exec=xdg-open http://127.0.0.1:8787
Icon=video-display
Terminal=false
Categories=AudioVideo;
EOF

# ---------- 7. TTS 모델 ----------
say "TTS 모델 (350MB, 최초 1회) — 몇 분 걸린다"
.venv/bin/python -c "from shortforge.tts import ensure_models; from pathlib import Path; ensure_models(Path('models'))" \
  || warn "모델 다운로드 실패 — 첫 렌더 때 자동 재시도한다."

# ---------- 8. 마무리 ----------
echo
if [ ${#MISSING[@]} -gt 0 ]; then
  warn "설치 못 한 것: ${MISSING[*]}"
  warn "크로미움이 여기 있으면 로그인/업로드가 안 되니 꼭 해결해라."
fi
sleep 1
if curl -s -o /dev/null --max-time 3 http://127.0.0.1:8787/api/state; then
  say "가동 확인 → http://127.0.0.1:8787"
else
  warn "아직 서버가 안 떴다. 터미널에서: shortforge web"
fi
xdg-open http://127.0.0.1:8787 >/dev/null 2>&1 || true
say "끝. 브라우저에서 [YouTube 로그인] 부터."
