# 크롬북(ChromeOS Linux)에서 시작하기

## 설치 — 터미널에 두 줄

```bash
cd ~ && curl -LO https://raw.githubusercontent.com/jaban112/shortforge/main/shortforge_v2.0.0.zip
unzip -q shortforge_v2.0.0.zip && cd shortforge && bash install.sh
```

파일 앱으로 옮길 필요 없다. sudo 비밀번호를 한 번 물어보고, 5~10분 뒤
**http://127.0.0.1:8787** 이 열린다.

설치되는 것: ffmpeg · chromium · python3 venv + 의존성 · `shortforge` 명령 ·
백그라운드 서비스(리눅스 켜지면 자동 시작) · 런처 아이콘 · TTS 모델 350MB.
패키지 하나가 실패해도 멈추지 않고, 끝에 못 깐 것만 모아서 알려준다.

## 쓰기 — 클릭 네 번

1. **[YouTube 로그인]** → 크로미움 창이 뜬다 → 평소처럼 구글 로그인 → 창 닫지 말고 앱으로
2. **[확인]** → 점이 초록이면 됨
3. 설정에서 **공개 범위 `unlisted`** 로 바꾸고 → **[지금 1편 만들어 올리기]** (약 5분)
4. 영상 확인했으면 `public` 으로 바꾸고 → **자동화 스위치 ON**

Instagram 도 쓰려면 2번 카드에서 똑같이. 자동화 카드에서 체크하면 같이 올라간다.

## 막히면

| 증상 | 할 일 |
|---|---|
| 크로미움 창이 안 뜸 | `systemctl --user stop shortforge-web` 후 터미널에서 `shortforge web` |
| 업로드가 중간에 멈춤 | 앱 **게시 기록**에 실패 단계 + **스크린샷** 링크 → 그 이미지를 Claude 에게 |
| 점이 빨감 | 세션 만료 → **[로그인]** 다시 |
| `shortforge` 명령을 못 찾음 | 터미널 새로 열기 (PATH 반영) 또는 `~/shortforge/.venv/bin/python -m shortforge web` |
| 크로미움이 안 깔림 | `sudo apt update && sudo apt install -y chromium` |
| 서비스 상태·로그 | `systemctl --user status shortforge-web` / `journalctl --user -u shortforge-web -f` |
| 재시작 | `systemctl --user restart shortforge-web` |
| 점검 | `shortforge doctor` |
| 완전 삭제 | `systemctl --user disable --now shortforge-web; rm -rf ~/shortforge` |

## 백업할 것

- `state/ledger.sqlite` — 뭘 썼고 뭘 올렸는지 (지우면 같은 소재를 다시 쓴다)
- `state/chrome-profile/` — 로그인 세션 (지우면 재로그인)
- `out/` — 만든 mp4 + 썸네일

## 참고

- Crostini(Debian)·Arch(baguette)·Ubuntu 전부에서 같은 `install.sh` 가 돈다.
- 이 앱은 **네 브라우저를 대신 조작**해서 올린다. API 키·Google Cloud·Meta 앱이 필요 없는
  대신, 사이트 UI 가 바뀌면 깨질 수 있다. 그때는 실패 스크린샷이 수리의 입력값이다.
- 수익은 YouTube 파트너 승인(구독 1,000 + 90일 Shorts 조회 1,000만) 뒤의 얘기고,
  승인은 사람 심사다. 보장된 게 아니다.
