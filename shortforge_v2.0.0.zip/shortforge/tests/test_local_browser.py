"""CDP attach to a real Chromium process (its own module: sync_playwright cannot nest)."""
from __future__ import annotations

import pytest

pytest.importorskip("playwright.sync_api")


def test_browser_cdp_attach(tmp_path):
    from shortforge.local.browser import Browser, cdp_alive, find_browsers

    assert find_browsers(), "no chromium available"
    # no exe= : exercises the candidate chain, so a broken system package (Ubuntu's snap
    # stub in CI) falls through to Playwright's bundled build instead of failing the run
    b = Browser(tmp_path / "profile", port=9555, log=lambda *_: None, headless=True)
    try:
        b.ensure_running()
        assert cdp_alive(9555)
        assert b.exe in find_browsers()
        ctx = b.connect()
        page = ctx.new_page()
        page.goto("data:text/html,<title>cdp-ok</title>")
        assert page.title() == "cdp-ok"
        page.close()
        b.close_connection()
        assert cdp_alive(9555)  # detaching must not kill the user's browser
        ctx2 = b.connect()      # re-attach works
        assert ctx2 is not None
        b.close_connection()
    finally:
        b.stop()




def test_browser_falls_through_broken_candidates(tmp_path):
    """A candidate that exits immediately must not end the search."""
    from shortforge.local.browser import Browser, find_browsers

    broken = tmp_path / "broken-chromium"
    broken.write_text("#!/bin/sh\nexit 3\n")
    broken.chmod(0o755)
    b = Browser(tmp_path / "profile", port=9556, log=lambda *_: None, headless=True)
    b.candidates = [str(broken), *find_browsers()]
    try:
        b.ensure_running()
        assert b.exe != str(broken)
    finally:
        b.stop()


def test_browser_reports_every_failure(tmp_path):
    """With no working candidate, the error names each one and why."""
    from shortforge.local.browser import Browser

    broken = tmp_path / "broken-chromium"
    broken.write_text("#!/bin/sh\nexit 3\n")
    broken.chmod(0o755)
    b = Browser(tmp_path / "profile", port=9558, log=lambda *_: None, headless=True, exe=str(broken))
    try:
        b.ensure_running()
    except RuntimeError as e:
        assert "broken-chromium" in str(e) and "code 3" in str(e)
    else:
        raise AssertionError("expected RuntimeError")
    finally:
        b.stop()
